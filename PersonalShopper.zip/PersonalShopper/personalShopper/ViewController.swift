//
//  ViewController.swift
//  personalShopper
//
//  Created by هلا العجلان on 9/18/18.
//  Copyright © 2018 hala. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth
import JSQMessagesViewController

class ViewController: UIViewController {

    let profileImage = UIImage(named: "Image-1")

    @IBOutlet weak var emailText: UITextField!
  //  hjkl;
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var msg: UILabel!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var actionButton: UIButton!
    func checkFields(){
        
        if segmentControl.selectedSegmentIndex == 0 //loginn
        {
            if emailText.text == "" || passwordText.text == ""{
                self.msg.text = self.errorMessage(errorCode: 2)}
        }
         else //sign up
        {
            if emailText.text == "" || passwordText.text == "" || userName.text=="" || name.text==""{
                
                self.msg.text = self.errorMessage(errorCode: 2)

            }
            
            
        }
            
            
        
        
    }
    @IBAction func action(_ sender: Any) {
        checkFields();
        if emailText.text != "" && passwordText.text != ""{
            if segmentControl.selectedSegmentIndex == 0 //loginn
            {   Auth.auth().signIn(withEmail: emailText.text!, password: passwordText.text!) { (user, error) in
                 if user != nil {
                    
   self.performSegue(withIdentifier: "goTotabBar", sender: self)     }
                
                 else {
                    if let myError=error?.localizedDescription
                    {print(myError)
                        self.msg.text=(self.errorMessage(errorCode: error?._code ?? 0))
 }
                    else
                    {  print("Error")}}
                //
}}
                               else //sign up
            { if name.text != "" && userName.text != ""  {
                    let Users = Database.database().reference().child("Users")
                Users.observeSingleEvent(of: .value, with: { (snapshot) in
                    if snapshot.hasChild(self.userName.text!){
                       self.msg.text = self.errorMessage(errorCode: 1) }
                    else {
                        Auth.auth().createUser(withEmail: self.emailText.text!, password: self.passwordText.text!){ (user, error) in
                            if user != nil {
                                let registeredUser=["name": self.name.text! as String, "userName" : self.userName.text! as String , "email": self.emailText.text! as String]
                                (Users).child(self.userName.text!).updateChildValues(registeredUser);
                                let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                                changeRequest?.displayName = self.userName.text!
                                changeRequest?.commitChanges { (error) in
                                    // ...
                                }
                                
                                /////////////////
                                let imageName = "default"
                                   // let storageRef = Storage.storage().reference()
                                   //  let  databaseRefer=Database.database().reference().child("Users")
                                let storeImage = Storage.storage().reference().child("profile_images").child(imageName)
                                if let uploadData = UIImagePNGRepresentation(self.profileImage!){
                                    print("line 42")
                                    
                                    
                                    storeImage.putData(uploadData, metadata: nil, completion: { (metadata , error) in
                                        if error != nil {
                                            print("line 47")
                                            
                                            print(error)
                                            return
                                        }
                                        print("line 52")
                                        
                                        storeImage.downloadURL(completion: {(url , error) in
                                            if error != nil {
                                                print(error)
                                                return
                                            }
                                            if let urlText=url?.absoluteString{
                                                let pic = ["image":urlText]
                                                
                                                Database.database().reference().child("Users").child(self.userName.text!).updateChildValues((pic), withCompletionBlock:{ (error , ref ) in
                                                    if error != nil {
                                                        print(error)
                                                        return
                                                    }
                                                    
                                                })
                                            }
                                        })
                                        
                                    })
                                }
                                
                                ////////////////////////
                                
                                
                                self.performSegue(withIdentifier: "goTotabBar", sender: self)
                            }
                            else
                            { if let myError=error?.localizedDescription
                            { print(myError)
                                // self.msg.text=myError
                                self.msg.text=(self.errorMessage(errorCode: error?._code ?? 0))
                                
                            }
                            else
                            { print("error line 62")
                                self.msg.text=("Error")
                                }}
                            
                        }
                    
                    }
                })//
                
                                }}
            }//end of checking if the user name already exist
            }
                
    func errorMessage(errorCode:Int) -> String{
        var msg:String
        switch (errorCode){
        case 1:
            msg="The user name is taken"
            break;
        case 2:
            msg="Please fill all fields"
            break;
        case 17007:
            msg="the email address is already registered"
            break
        case 17008:
            msg="The email address is invalid"
            break

        case 17009:
            msg="The password is wrong , please try again"
       break
        case 17011:
            msg="cannot find account, please try again"
            break
        case 17026:
            msg="The password too short, it must be 6 characters or more"
            break
        default:
            msg="something is wrong, please try again"
        }
    return msg
    }
            
    
    
    @IBAction func swap(_ sender: UISegmentedControl) {
        if segmentControl.selectedSegmentIndex == 0
        {name.isHidden=true;
            userName.isHidden=true;
            
        }
        else {

        name.isHidden=false;
            userName.isHidden=false;

        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        name.isHidden=true;
        userName.isHidden=true;
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
   
    
   
    
    
    
    }
    
    


