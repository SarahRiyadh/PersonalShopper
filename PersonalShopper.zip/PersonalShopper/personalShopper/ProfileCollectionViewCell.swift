//
//  ProfileCollectionViewCell.swift
//  personalShopper
//
//  Created by هلا العجلان on 11/5/18.
//  Copyright © 2018 hala. All rights reserved.
//

import UIKit
import Firebase

class ProfileCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var pImage: UIImageView!
    @IBOutlet weak var pDescription: UILabel!
    
    
    
    
//    var getURL: String?
//    
//    
//    var post: Post! {
//        didSet {
//            self.updateUI()
//        }
//    }
//    func updateUI() {
//        
//    
//        // caption
//        self.pDescription.text = post.caption
//        // download image
//        if let getURL = post.downloadURL{
//            print("123456789p ")
//            
//            // Create a reference to the file you want to download
//            let imageStorageRef = Storage.storage().reference(forURL: getURL)
//            // Download in memory with a maximum allowed size of 1MB (1 * 1024 * 1024 bytes)
//            imageStorageRef.getData(maxSize: 2 * 1024 * 1024) { (data, error) in
//                if let error = error {
//                    print("******** \(error)")
//                } else {
//                    // Data for "images/island.jpg" is returned
//                    if let imageData = data {
//                        let image = UIImage(data: imageData)
//                        //   DispatchQueue.main.async {
//                        self.pImage.image = image
//                        //  }
//                    }
//                }
//            }
//            
//        }
//        else{
//            print("****FAAIL to download url****")
//            
//        }
//    }
    
    
    
    
    
}
