//
//  ViewController8.swift
//  personalShopper
//
//  Created by هلا العجلان on 11/6/18.
//  Copyright © 2018 hala. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth
class ViewController10: UIViewController , UICollectionViewDelegate , UICollectionViewDataSource  , UINavigationControllerDelegate  {
    let storageRef = Storage.storage().reference()
    let  databaseRefer=Database.database().reference().child("Users")
    
    @IBAction func Chatting(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "Chat", sender:self)

    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        
        if let vc = segue.destination as? ChatViewController
        {
            print("Chaaaaaaaaat ussserrrr=",chatUser)
            vc.receiver = chatUser;
            
        }}
    
    
    @IBOutlet weak var userImage: UIImageView!
    var userNAme:String = "";
    
   
    
   
    var posts = [Post]()
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return posts.count;
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let imagV:ViewController9=self.storyboard?.instantiateViewController(withIdentifier: "imgView") as! ViewController9
        imagV.selectedImage = posts[indexPath.row].image
        self.navigationController?.pushViewController(imagV, animated: true);
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ProfileCollectionViewCell
        cell.pDescription.text=posts[indexPath.item].caption;
        cell.pImage.image=posts[indexPath.item].image;
        // cell.post=posts[indexPath.item]
        return cell;
        
    }
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var collectionV: UICollectionView!
    var userName:String!
    var chatUser:String!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionV.dataSource=self;
        collectionV.delegate=self;
        userImage.layer.cornerRadius = userImage.frame.size.width/2 ;
        userImage.clipsToBounds = true;
        chatUser=userNAme;
        
        let storesDB = Database.database().reference().child("Stores")
        storesDB.observe(DataEventType.value, with: { (snapshot) in
            if snapshot.childrenCount>0{
                //   self.posts.removeAll()                     let storeObj = stores.value as? [String:AnyObject]
                print("line 135 ")
                
                for stores in snapshot.children.allObjects as! [DataSnapshot] {
                    print("line 138 ")
                    
                    let storeObj = stores.value as? [String:AnyObject]
                    if storeObj == nil
                    {
                        return;
                    }
                    let storeName=storeObj!["StoreName"] as! String
                    let city=storeObj!["City"] as! String
                    let  key=(storeName+city).uppercased()
                    print(storeName)
                    print(key)
                    storesDB.child(key).child("products").observe(DataEventType.value, with: { (snapshot) in
                        print("line 146 ")
                        print(key)
                        
                        if snapshot.childrenCount>0{
                            self.posts.removeAll()
                            print("line 149 ")
                            
                            for products in snapshot.children.allObjects as! [DataSnapshot] {
                                print("line 157")
                                let productObj = products.value as? [String:AnyObject]
                                if productObj == nil {
                                    print("product obj is nill")
                                    
                                    return ;
                                }
                                let user = productObj!["by"] as! String
                                print("user ===",user)
                                print("line 145 ")
                                if user  == self.userNAme {
                                    print("line user====userrrr")
                                    
                                    
                                    
                                    //  Database.database().reference().child("posts").observe(.childAdded) { (snapshot) in
                                    //            // snapshot is now a dictionary
                                    let newPost = Post(snapshot: snapshot)
                                    
                                    //            databaseRefer.child(self.userName.text!).observeSingleEvent(of: .value, with: { (snapshot) in
                                    // Get user value
                                    //  let value = snapshot.value as? NSDictionary
                                    
                                    if let profileImageURL = productObj!["imageDownloadURL"] as? String {
                                        print("line 164")
                                        
                                        if let url = URL(string: profileImageURL){
                                            print("line 166")
                                            
                                            URLSession.shared.dataTask(with: url, completionHandler:{ (data , response , error) in
                                                
                                                if error != nil{
                                                    print(error)
                                                    return}
                                                print("line 173")
                                                
                                                
                                                newPost.image = UIImage(data: data!)
                                                newPost.caption=productObj!["caption"] as? String
                                                self.posts.append(newPost)
                                                
                                                DispatchQueue.main.async {
                                                    
                                                    self.collectionV.reloadData()
                                                }
                                                
                                            }
                                                )    .resume()
                                            
                                            
                                            // end  if let url = URL(string: profileImageURL)
                                            
                                        }//end  if let profileImageURL = value!["image"] as? String
                                        
                                        
                                        // Do any additional setup after loading the view.
                                    }}
                            }}
                    })
                }}})
        databaseRefer.child(userNAme).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            let N = value!["userName"] as! String
            self.name.text=N;
            if let profileImageURL = value!["image"] as? String {
                if let url = URL(string: profileImageURL){
                    URLSession.shared.dataTask(with: url, completionHandler:{ (data , response , error) in
                        if error != nil{
                            print(error)
                            return}
                        DispatchQueue.main.async {
                            
                            self.userImage?.image = UIImage(data: data!)}
                    }
                        
                        
                        ) .resume()
                    
                }// end  if let url = URL(string: profileImageURL)
            }//end  if let profileImageURL = value!["image"] as? String
            
        }) { (error) in
            print("some error line 28 VC 6")
        }
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
