//
//  ViewController13.swift
//  personalShopper
//
//  Created by هلا العجلان on 11/26/18.
//  Copyright © 2018 hala. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth
class ViewController13: UIViewController,UITableViewDataSource , UITableViewDelegate {
    @IBOutlet weak var tableV: UITableView!
    var users = [UserModel]()
    var chatUser:String!

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count;
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        
//        if let vc = segue.destination as? ChatViewController
//        {
//            print("Chaaaaaaaaat ussserrrr=",chatUser)
//            vc.receiver = chatUser;
//
//        }
        if let controller = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "nav") as? UINavigationController,
            let vc = controller.viewControllers.first as? ChatViewController {
            vc.receiver = chatUser ;
            vc.showBtn = true;
//            self.window?.rootViewController = controller  // if presented from AppDelegate
             present(controller, animated: true, completion: nil) // if presented from ViewController
        }
        
        
        
    }
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      chatUser=users[indexPath.row].name
//        print("user  to gggoooo ====",userTogo)
        
//
//        let imagV:ChatViewController=self.storyboard?.instantiateViewController(withIdentifier: "chatV") as! ChatViewController
//        imagV.receiver = users[indexPath.row].name!
//        print("line 36 vc13")
//        self.navigationController?.pushViewController(imagV, animated: true);
//
        
   //
    
    self.performSegue(withIdentifier: "Chat", sender:self)
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "chatCell", for: indexPath) as! ChatTableViewCell
        let user = self.users[indexPath.row]
        
        cell.pic.image=user.pic
        cell.label.text=user.name

      //   cell.pic.layer.borderWidth = 1
//         cell.pic.layer.masksToBounds = false
//         cell.pic.layer.borderColor = UIColor.black.cgColor
//         cell.pic.layer.cornerRadius = cell.pic.frame.height/2
//         cell.pic.clipsToBounds = true
        return cell;
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tableV.rowHeight = 70;
        let UsersDB = Database.database().reference().child("Users")
        UsersDB.observe(DataEventType.value, with: { (snapshot) in
            if snapshot.childrenCount>0{
                self.users.removeAll()
                for useres in snapshot.children.allObjects as![DataSnapshot]{
                    let userObj = useres.value as? [String:AnyObject]
                    if userObj==nil {
                    print("USER IS NIL LINE 37")
                        return;}
                    else {
                        print("user name===",userObj?["userName"])

                        print("profile imege===",userObj?["image"])
let newUser = UserModel(snapshot: snapshot)
                        if let profileImageURL = userObj?["image"] as? String {
                            print("LINE 42")
                            if let url = URL(string: profileImageURL){
                                print("LINE 44")

                                URLSession.shared.dataTask(with: url, completionHandler:{ (data , response , error) in
                                    print("line 48")

                                    if error != nil{
                                        print(error)
                                        print("line 50")
                                        return}
                                    print("line 173")
                                    
                                    newUser.name = userObj!["userName"] as? String ;
                                    
                                    
                                    newUser.pic = UIImage(data: data!)
                                    
                                    self.users.append(newUser)
                                    
                                    DispatchQueue.main.async {
                                        print("LINE 58")

                                        self.tableV.reloadData()
                                    }
                                    
                                }
                                    )    .resume()
                                
                                print("line 65")

                                
                                
                                // end  if let url = URL(string: profileImageURL)
                                
                            }//end  if let profileImageURL = value!["image"] as? String
                            
                            
                            // Do any additional setup after loading the view.
                        }
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                       
                        
                    }
                    
                }
            }})
        
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

