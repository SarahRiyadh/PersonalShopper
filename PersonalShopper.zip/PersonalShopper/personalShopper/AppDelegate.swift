//
//  AppDelegate.swift
//  personalShopper
//
//  Created by هلا العجلان on 9/18/18.
//  Copyright © 2018 hala. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import UserNotifications
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    var window: UIWindow?
    
    public func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Swift.Void){
        //display notification even if the app is in forward
        completionHandler([.alert, .sound])
    }
    
    public func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Swift.Void){
        if response.notification.request.identifier == "testIdentifier"{
            //if the app has this identifier
            //open specific page for example
            
        }
        
    }
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        //
        FirebaseApp.configure()

        UNUserNotificationCenter.current().delegate = self
        //this is for ask the user weather to send notification
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.badge,.sound] ){ (granted, error) in
            print("granted: \(granted)")
        }
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        
    }
    
    
    
    
    
    
}

