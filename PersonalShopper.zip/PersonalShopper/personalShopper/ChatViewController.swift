//
//  ChatViewController.swift
//  personalShopper
//
//  Created by هلا العجلان on 11/17/18.
//  Copyright © 2018 hala. All rights reserved.
//

import UIKit
import FirebaseAuth
import JSQMessagesViewController
class ChatViewController: JSQMessagesViewController {
    var user = Auth.auth().currentUser?.displayName;
    var messages = [JSQMessage]()
    var receiver = "";
    var showBtn = false;
    var key = "";
    lazy var outgoingBubble: JSQMessagesBubbleImage = {
        return JSQMessagesBubbleImageFactory()!.outgoingMessagesBubbleImage(with: UIColor.jsq_messageBubbleBlue())
    }()
    
    lazy var incomingBubble: JSQMessagesBubbleImage = {
        return JSQMessagesBubbleImageFactory()!.incomingMessagesBubbleImage(with: UIColor.jsq_messageBubbleLightGray())
    }()
    
    
    @objc func back() {
        
 dismiss(animated: true, completion: nil)    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //////// to hide the nav bar ///////////
       self.edgesForExtendedLayout = []
        if (user! > receiver){
            key = (user!+"TO"+receiver).uppercased()}
            
            else {
                self.key = (receiver+"TO"+user!).uppercased()        }
        
        
        
print("Kkkkkkkkkeeeeeey====",key)
       // let defaults = UserDefaults.standard
        
        if  let id = user
            //, let name = defaults.string(forKey: "jsq_name")
        {
            senderId = id
            senderDisplayName = user
        }
        else
        {
            senderId = String(arc4random_uniform(999999))
            senderDisplayName = ""
            
//            defaults.set(senderId, forKey: "jsq_id")
//            defaults.synchronize()
//
           // showDisplayNameDialog()
        }
        
        title = "Chat: \(senderDisplayName!)"
        
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(showDisplayNameDialog))
//        tapGesture.numberOfTapsRequired = 1
        
//        navigationController?.navigationBar.addGestureRecognizer(tapGesture)
//        let leftButton = UIButton(title: "Back", style: .plain, target: self, action: #selector(self.back))
        if(showBtn){
            let leftButton = UIButton(type: .system)
            leftButton.setTitle("back", for: .normal)
            leftButton.addTarget(self, action: #selector(self.back), for: .touchUpInside)
            inputToolbar.contentView.leftBarButtonItem = leftButton
        }
        else {
            inputToolbar.contentView.leftBarButtonItem = nil

        }

        collectionView.collectionViewLayout.incomingAvatarViewSize = CGSize.zero
        collectionView.collectionViewLayout.outgoingAvatarViewSize = CGSize.zero
        print("rrrrr==",receiver)

        // Do any additional setup after loading the view.
        let query = Constants.refs.databaseChats.child(key).queryLimited(toLast: 10)
        
        _ = query.observe(.childAdded, with: { [weak self] snapshot in
            
            if  let data        = snapshot.value as? [String: String],
                let id          = data["sender_id"],
                let name        = data["name"],
                let text        = data["text"],
                !text.isEmpty
            {
              
                if let message = JSQMessage(senderId: id, displayName: name, text: text)
                {
                    self?.messages.append(message)
                    
                    self?.finishReceivingMessage()
                }
            }
        })
    }
    @objc func showDisplayNameDialog()
    {
        print("rrrrr   llllliiiiiiinnnnn444 88881111==",receiver)

        let defaults = UserDefaults.standard
        
        let alert = UIAlertController(title: "Your Display Name", message: "Before you can chat, please choose a display name. Others will see this name when you send chat messages. You can change your display name again by tapping the navigation bar.", preferredStyle: .alert)
        
        alert.addTextField { textField in
            
            if let name = defaults.string(forKey: "jsq_name")
            {
                textField.text = name
            }
            else
            {
                let names = ["Ford", "Arthur", "Zaphod", "Trillian", "Slartibartfast", "Humma Kavula", "Deep Thought"]
                textField.text = names[Int(arc4random_uniform(UInt32(names.count)))]
            }
        }
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak self, weak alert] _ in
            
            if let textField = alert?.textFields?[0], !textField.text!.isEmpty {
                
                self?.senderDisplayName = textField.text
                
                self?.title = "Chat: \(self!.senderDisplayName!)"
                
                defaults.set(textField.text, forKey: "jsq_name")
                defaults.synchronize()
            }
        }))
        
        present(alert, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, messageDataForItemAt indexPath: IndexPath!) -> JSQMessageData!
    {
        return messages[indexPath.item]
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return messages.count
    }
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, messageBubbleImageDataForItemAt indexPath: IndexPath!) -> JSQMessageBubbleImageDataSource!
    {
        return messages[indexPath.item].senderId == senderId ? outgoingBubble : incomingBubble
    }
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, avatarImageDataForItemAt indexPath: IndexPath!) -> JSQMessageAvatarImageDataSource!
    {
        return nil
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, attributedTextForMessageBubbleTopLabelAt indexPath: IndexPath!) -> NSAttributedString!
    {
        return messages[indexPath.item].senderId == senderId ? nil : NSAttributedString(string: messages[indexPath.item].senderDisplayName)
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, layout collectionViewLayout: JSQMessagesCollectionViewFlowLayout!, heightForMessageBubbleTopLabelAt indexPath: IndexPath!) -> CGFloat
    {
        return messages[indexPath.item].senderId == senderId ? 0 : 15
    }
    override func didPressSend(_ button: UIButton!, withMessageText text: String!, senderId: String!, senderDisplayName: String!, date: Date!)
    {
        let ref = Constants.refs.databaseChats.child(key).childByAutoId()
        
        let message = ["sender_id": senderId, "name": senderDisplayName, "text": text, "receiver_id": receiver ]
        
        ref.setValue(message)
        
        finishSendingMessage()
    }
    override func didPressAccessoryButton(_ sender: UIButton!) {
        dismiss(animated: true, completion: nil)    

    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
