//
//  StoreModel.swift
//  personalShopper
//
//  Created by هلا العجلان on 9/23/18.
//  Copyright © 2018 hala. All rights reserved.
//

class StoreModel {
    
    var name: String?
    var city: String?
    
    init(name:String?, city:String?) {
        self.name=name;
        self.city=city;
    }
    
    
    
}
