//
//  CartCollectionViewCell.swift
//  personalShopper
//
//  Created by هلا العجلان on 11/27/18.
//  Copyright © 2018 hala. All rights reserved.
//

import UIKit

class CartCollectionViewCell: ProfileCollectionViewCell {
    
     @IBOutlet weak var image: UIImageView!
}
