//
//  SearchStoreTableViewController.swift
//  
//
//  Created by هلا العجلان on 9/27/18.
//

import UIKit
import FirebaseDatabase
class SearchStoreTableViewController: UITableViewController, UISearchResultsUpdating {
    @IBOutlet var FindStoreTableView: UITableView!
    
    let searchController = UISearchController(searchResultsController: nil)
    var storeArray = [NSDictionary?]()
    var filteredStores = [NSDictionary?]()
    var databaseRef = Database.database().reference()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        
        databaseRef.child("Stores").queryOrdered(byChild:"StoreName").observe(.childAdded , with: {(snapshot) in
            
            self.storeArray.append(snapshot.value as? NSDictionary)
            
            self.FindStoreTableView.insertRows(at: [IndexPath(row:self.storeArray.count-1,section:0)],with: UITableViewRowAnimation.automatic)
            
        }) { (error) in
            print(error.localizedDescription)
            
        }

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if searchController.isActive && searchController.searchBar.text != ""{
            return filteredStores.count
        }
        return self.storeArray.count
    }
    var storeTogo:String!;
    var cityTogo:String!;


   override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    let user = self.storeArray[indexPath.row]
    storeTogo = user?["StoreName"] as? String
    cityTogo = user?["City"] as? String
    print("user  to gggoooo ====",storeTogo)
    self.performSegue(withIdentifier: "toProfile", sender:self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        
        if let vc = segue.destination as? ViewController11
        {
            print("store=",storeTogo)
            vc.storeName = storeTogo;
            vc.city=cityTogo;
            
            
        }}
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let store : NSDictionary?
        
        if searchController.isActive && searchController.searchBar.text != "" {
            store = filteredStores[indexPath.row]
        }
        else{
            store = self.storeArray[indexPath.row]
        }
        cell.textLabel?.text = store?["StoreName"] as? String
        cell.detailTextLabel?.text=store?["City"] as? String
        
        return cell
    }
    @IBAction func dismiss(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        filterContent(searchText: self.searchController.searchBar.text!)
    }
    
    func filterContent(searchText:String){
        
        self.filteredStores = self.storeArray.filter{ store in
            let storeName = store?["StoreName"] as? String
            return(storeName?.lowercased().contains(searchText.lowercased()))!
        }
        tableView.reloadData()
    }
    
}
